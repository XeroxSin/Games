# discord-games
A Discord bot for playing games such as tic-tac-toe, Go, chess, ...


Prerequisite: https://github.com/Rapptz/discord.py
